import { TarotCardData } from '../types';

// Classic Rider-Waite-Smith Deck Images (Public Domain)
const CARD_IMAGES = [
  "https://upload.wikimedia.org/wikipedia/commons/9/90/RWS_Tarot_00_Fool.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/d/de/RWS_Tarot_01_Magician.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/8/88/RWS_Tarot_02_High_Priestess.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/d/d2/RWS_Tarot_03_Empress.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/c/c3/RWS_Tarot_04_Emperor.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/8/8d/RWS_Tarot_05_Hierophant.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/3/3a/RWS_Tarot_06_Lovers.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/9/9b/RWS_Tarot_07_Chariot.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/f/f5/RWS_Tarot_08_Strength.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/4/4d/RWS_Tarot_09_Hermit.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/3/3c/RWS_Tarot_10_Wheel_of_Fortune.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/e/e0/RWS_Tarot_11_Justice.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/2/2b/RWS_Tarot_12_Hanged_Man.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/d/d7/RWS_Tarot_13_Death.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/f/f8/RWS_Tarot_14_Temperance.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/5/55/RWS_Tarot_15_Devil.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/5/53/RWS_Tarot_16_Tower.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/d/db/RWS_Tarot_17_Star.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/7/7f/RWS_Tarot_18_Moon.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/1/17/RWS_Tarot_19_Sun.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/d/dd/RWS_Tarot_20_Judgement.jpg",
  "https://upload.wikimedia.org/wikipedia/commons/f/ff/RWS_Tarot_21_World.jpg"
];

const BASE_ARCANA: TarotCardData[] = [
  { id: 0, name: "The Fool", nameCN: "愚者", image: CARD_IMAGES[0], meaningUpright: "New beginnings, innocence, spontaneity", meaningReversed: "Recklessness, risk-taking, bad choices" },
  { id: 1, name: "The Magician", nameCN: "魔术师", image: CARD_IMAGES[1], meaningUpright: "Manifestation, resourcefulness, power", meaningReversed: "Manipulation, poor planning, untapped talents" },
  { id: 2, name: "The High Priestess", nameCN: "女祭司", image: CARD_IMAGES[2], meaningUpright: "Intuition, sacred knowledge, divine feminine", meaningReversed: "Secrets, disconnected from intuition, withdrawal" },
  { id: 3, name: "The Empress", nameCN: "皇后", image: CARD_IMAGES[3], meaningUpright: "Femininity, beauty, nature, nurturing", meaningReversed: "Creative block, dependence on others" },
  { id: 4, name: "The Emperor", nameCN: "皇帝", image: CARD_IMAGES[4], meaningUpright: "Authority, establishment, structure", meaningReversed: "Domination, excessive control, lack of discipline" },
  { id: 5, name: "The Hierophant", nameCN: "教皇", image: CARD_IMAGES[5], meaningUpright: "Spiritual wisdom, religious beliefs, conformity", meaningReversed: "Personal beliefs, freedom, challenging status quo" },
  { id: 6, name: "The Lovers", nameCN: "恋人", image: CARD_IMAGES[6], meaningUpright: "Love, harmony, relationships, values alignment", meaningReversed: "Self-love, disharmony, imbalance, misalignment" },
  { id: 7, name: "The Chariot", nameCN: "战车", image: CARD_IMAGES[7], meaningUpright: "Control, willpower, success, action", meaningReversed: "Self-discipline, opposition, lack of direction" },
  { id: 8, name: "Strength", nameCN: "力量", image: CARD_IMAGES[8], meaningUpright: "Strength, courage, persuasion, influence", meaningReversed: "Inner strength, self-doubt, low energy, raw emotion" },
  { id: 9, name: "The Hermit", nameCN: "隐士", image: CARD_IMAGES[9], meaningUpright: "Soul-searching, introspection, being alone", meaningReversed: "Isolation, loneliness, withdrawal" },
  { id: 10, name: "Wheel of Fortune", nameCN: "命运之轮", image: CARD_IMAGES[10], meaningUpright: "Good luck, karma, life cycles, destiny", meaningReversed: "Bad luck, resistance to change, breaking cycles" },
  { id: 11, name: "Justice", nameCN: "正义", image: CARD_IMAGES[11], meaningUpright: "Justice, fairness, truth, cause and effect", meaningReversed: "Unfairness, lack of accountability, dishonesty" },
  { id: 12, name: "The Hanged Man", nameCN: "倒吊人", image: CARD_IMAGES[12], meaningUpright: "Pause, surrender, letting go, new perspectives", meaningReversed: "Delays, resistance, stalling, indecision" },
  { id: 13, name: "Death", nameCN: "死神", image: CARD_IMAGES[13], meaningUpright: "Endings, change, transformation, transition", meaningReversed: "Resistance to change, personal transformation, inner purging" },
  { id: 14, name: "Temperance", nameCN: "节制", image: CARD_IMAGES[14], meaningUpright: "Balance, moderation, patience, purpose", meaningReversed: "Imbalance, excess, self-healing, re-alignment" },
  { id: 15, name: "The Devil", nameCN: "恶魔", image: CARD_IMAGES[15], meaningUpright: "Shadow self, attachment, addiction, restriction", meaningReversed: "Releasing limiting beliefs, exploring dark thoughts" },
  { id: 16, name: "The Tower", nameCN: "高塔", image: CARD_IMAGES[16], meaningUpright: "Sudden change, upheaval, chaos, revelation", meaningReversed: "Personal transformation, fear of change, averting disaster" },
  { id: 17, name: "The Star", nameCN: "星星", image: CARD_IMAGES[17], meaningUpright: "Hope, faith, purpose, renewal, spirituality", meaningReversed: "Lack of faith, despair, self-trust, disconnection" },
  { id: 18, name: "The Moon", nameCN: "月亮", image: CARD_IMAGES[18], meaningUpright: "Illusion, fear, anxiety, subconscious, intuition", meaningReversed: "Release of fear, repressed emotion, inner confusion" },
  { id: 19, name: "The Sun", nameCN: "太阳", image: CARD_IMAGES[19], meaningUpright: "Positivity, fun, warmth, success, vitality", meaningReversed: "Inner child, feeling down, overly optimistic" },
  { id: 20, name: "Judgement", nameCN: "审判", image: CARD_IMAGES[20], meaningUpright: "Judgement, rebirth, inner calling, absolution", meaningReversed: "Self-doubt, inner critic, ignoring the call" },
  { id: 21, name: "The World", nameCN: "世界", image: CARD_IMAGES[21], meaningUpright: "Completion, integration, accomplishment, travel", meaningReversed: "Seeking personal closure, short-cuts, delays" },
];

// Generate Reversed Cards (IDs 22-43)
const REVERSED_ARCANA: TarotCardData[] = BASE_ARCANA.map(card => ({
  ...card,
  id: card.id + 22,
  name: `${card.name} (Rev)`,
  nameCN: `${card.nameCN} (逆)`,
  // Initially use the same image, but user can override this specific slot
  image: card.image, 
}));

export const MAJOR_ARCANA: TarotCardData[] = [...BASE_ARCANA, ...REVERSED_ARCANA];

export const TAROT_BACK_TEXTURE = "https://www.transparenttextures.com/patterns/black-scales.png";

// Golden Cranes and Pine Tree Door - High resolution classic art style
export const DOOR_TEXTURE = "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Suzuki_Kiitsu_-_Cranes_-_Google_Art_Project.jpg/1280px-Suzuki_Kiitsu_-_Cranes_-_Google_Art_Project.jpg";
