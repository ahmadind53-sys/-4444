import { HandLandmark } from "../types";

export interface HandStatus {
  landmarks: HandLandmark[];
  gesture: 'NONE' | 'FIST' | 'OPEN' | 'ONE_FINGER';
  wristX: number; // Normalized 0-1
  wristY: number; // Normalized 0-1
  indexTipVelocityX: number; // Left/Right speed
  indexTipVelocityZ: number; // Depth speed (Positive = moving away/backwards)
}

export class HandDetector {
  private hands: any;
  private camera: any;
  private videoElement: HTMLVideoElement | null = null;
  private debugCtx: CanvasRenderingContext2D | null = null;
  private onResultsCallback: ((status: HandStatus | null) => void) | null = null;
  private isRunning: boolean = false;
  private isInitialized: boolean = false;
  
  // Previous frame data for velocity calculation
  private prevIndexTipX: number | null = null;
  private prevIndexTipZ: number | null = null;
  private lastTimestamp: number = 0;

  constructor() {
    // Constructor is empty, use initialize()
  }

  public async initialize(): Promise<void> {
    if (this.isInitialized) return;

    let attempts = 0;
    while ((!window.Hands || !window.Camera) && attempts < 20) {
      await new Promise(r => setTimeout(r, 200));
      attempts++;
    }

    if (!window.Hands) {
      throw new Error("MediaPipe Hands library not found");
    }

    try {
      this.hands = new window.Hands({
        locateFile: (file: string) => {
          // Use pinned version to match index.html and prevent Module.arguments errors
          return `https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1675469240/${file}`;
        }
      });

      this.hands.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.7,
        minTrackingConfidence: 0.5
      });

      this.hands.onResults(this.onResults.bind(this));
      this.isInitialized = true;
    } catch (e) {
      console.error("Failed to initialize MediaPipe Hands:", e);
      throw e;
    }
  }

  public setCallback(cb: (status: HandStatus | null) => void) {
    this.onResultsCallback = cb;
  }

  public setDebugCanvas(canvas: HTMLCanvasElement) {
    this.debugCtx = canvas.getContext('2d');
  }

  public async start(videoEl: HTMLVideoElement) {
    if (this.isRunning) return;
    if (!this.isInitialized) await this.initialize();
    
    this.videoElement = videoEl;
    this.isRunning = true;

    if (window.Camera && this.videoElement) {
      this.camera = new window.Camera(this.videoElement, {
        onFrame: async () => {
          // Robust checks to prevent "Aborted(native code called abort())"
          if (
            this.videoElement && 
            this.hands && 
            this.isRunning &&
            this.videoElement.readyState >= 2 && // HAVE_CURRENT_DATA
            this.videoElement.videoWidth > 0 && 
            this.videoElement.videoHeight > 0 &&
            !this.videoElement.paused
          ) {
            try {
              await this.hands.send({ image: this.videoElement });
            } catch (e) {
              // Suppress abort errors to keep app alive
              if (e instanceof Error && e.message.includes("abort")) {
                  console.warn("MediaPipe Abort detected, retrying next frame...");
              } else {
                  console.warn("MediaPipe send error:", e);
              }
            }
          }
        },
        width: 640,
        height: 480
      });
      await this.camera.start();
    }
  }

  public stop() {
    this.isRunning = false;
    if (this.camera) {
      try {
        this.camera.stop();
      } catch (e) {
        console.warn("Error stopping camera:", e);
      }
      this.camera = null;
    }
    if (this.debugCtx) {
      this.debugCtx.clearRect(0, 0, this.debugCtx.canvas.width, this.debugCtx.canvas.height);
    }
  }

  private onResults(results: any) {
    if (!this.isRunning) return;

    if (this.debugCtx) {
       const ctx = this.debugCtx;
       const { width, height } = ctx.canvas;
       ctx.save();
       ctx.clearRect(0, 0, width, height);
       
       // Draw skeleton
       if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
          const landmarks = results.multiHandLandmarks[0];
          if (window.drawConnectors && window.HAND_CONNECTIONS) {
             window.drawConnectors(ctx, landmarks, window.HAND_CONNECTIONS, {color: '#00f3ff', lineWidth: 2});
          }
          if (window.drawLandmarks) {
             window.drawLandmarks(ctx, landmarks, {color: '#d4af37', lineWidth: 1, radius: 3});
          }
       }
       ctx.restore();
    }

    if (!this.onResultsCallback) return;

    if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
      const landmarks = results.multiHandLandmarks[0];
      const gesture = this.detectGesture(landmarks);
      
      // Calculate Velocities
      const now = Date.now();
      const indexTipX = landmarks[8].x;
      const indexTipZ = landmarks[8].z; // Z is depth relative to wrist roughly
      
      let velocityX = 0;
      let velocityZ = 0;

      if (this.prevIndexTipX !== null && this.lastTimestamp > 0) {
        const dt = now - this.lastTimestamp;
        if (dt > 0) {
          // simple derivative units/sec
          velocityX = (indexTipX - this.prevIndexTipX) / dt * 1000; 
          velocityZ = (indexTipZ - this.prevIndexTipZ!) / dt * 1000;
        }
      }

      this.prevIndexTipX = indexTipX;
      this.prevIndexTipZ = indexTipZ;
      this.lastTimestamp = now;

      this.onResultsCallback({
        landmarks,
        gesture,
        wristX: landmarks[0].x,
        wristY: landmarks[0].y,
        indexTipVelocityX: velocityX,
        indexTipVelocityZ: velocityZ
      });
    } else {
      this.prevIndexTipX = null;
      this.prevIndexTipZ = null;
      this.onResultsCallback(null);
    }
  }

  private detectGesture(landmarks: any[]): 'NONE' | 'FIST' | 'OPEN' | 'ONE_FINGER' {
    const isTipBelowPip = (tipIdx: number, pipIdx: number) => {
       const wrist = landmarks[0];
       const tip = landmarks[tipIdx];
       const pip = landmarks[tipIdx - 2];
       return Math.hypot(tip.x - wrist.x, tip.y - wrist.y) < Math.hypot(pip.x - wrist.x, pip.y - wrist.y);
    };

    const indexExtended = !isTipBelowPip(8, 6);
    const middleExtended = !isTipBelowPip(12, 10);
    const ringExtended = !isTipBelowPip(16, 14);
    const pinkyExtended = !isTipBelowPip(20, 18);

    const extendedCount = (indexExtended ? 1 : 0) + (middleExtended ? 1 : 0) + (ringExtended ? 1 : 0) + (pinkyExtended ? 1 : 0);

    if (extendedCount === 4) return 'OPEN';
    if (extendedCount === 0) return 'FIST';
    if (indexExtended && !middleExtended && !ringExtended && !pinkyExtended) return 'ONE_FINGER';
    
    if (extendedCount >= 3) return 'OPEN';
    return 'NONE';
  }
}