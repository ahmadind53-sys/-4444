import React, { useState, useEffect, useRef, useCallback } from 'react';
import { TarotScene } from './components/TarotScene';
import { HUD } from './components/HUD';
import { DeckCustomizer } from './components/DeckCustomizer';
import { HandDetector, HandStatus } from './services/handDetection';
import { MAJOR_ARCANA } from './services/tarotData';
import { DrawResult, InputMode, TarotCardData } from './types';

const App: React.FC = () => {
  // Set started to true by default to open camera immediately
  const [started, setStarted] = useState(true);
  const [loading, setLoading] = useState(false);
  const [inputMode, setInputMode] = useState<InputMode>('hand');
  const [handStatus, setHandStatus] = useState<HandStatus | null>(null);
  
  // Application State
  const [drawState, setDrawState] = useState<'idle' | 'drawing' | 'revealed'>('idle');
  const [activeCardData, setActiveCardData] = useState<any>(null);
  const [history, setHistory] = useState<DrawResult[]>([]);
  const [isReversed, setIsReversed] = useState(false);

  // Deck State - Now contains 44 cards (22 Upright, 22 Reversed)
  const [deckData, setDeckData] = useState<TarotCardData[]>(MAJOR_ARCANA);
  const [showCustomizer, setShowCustomizer] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const detectorRef = useRef<HandDetector | null>(null);

  // Initialize Detector on Mount
  useEffect(() => {
    const initDetector = async () => {
      setLoading(true);
      const detector = new HandDetector();
      try {
        await detector.initialize();
        detector.setCallback((status) => {
          setHandStatus(status);
        });
        detectorRef.current = detector;
        console.log("HandDetector initialized");
      } catch (e) {
        console.error("Failed to init HandDetector", e);
      } finally {
        setLoading(false);
      }
    };
    initDetector();
  }, []);

  // Handle Camera Start/Stop based on 'started' and 'inputMode'
  useEffect(() => {
    if (!started || loading) return;

    if (inputMode === 'hand' && detectorRef.current && videoRef.current) {
      if (canvasRef.current) {
        detectorRef.current.setDebugCanvas(canvasRef.current);
      }
      detectorRef.current.start(videoRef.current).catch(err => console.error("Camera start failed:", err));
    } else {
      detectorRef.current?.stop();
      setHandStatus(null);
    }
  }, [started, inputMode, loading]);

  const handleStart = () => {
    setStarted(true);
  };

  // Callbacks from Scene
  const handleCardRevealed = useCallback((cardId: number, reversed: boolean) => {
    // Determine card from the full deck (0-43)
    const card = deckData.find(c => c.id === cardId);
    if (card) {
      setActiveCardData(card);
      // 'reversed' param passed from scene is technically derived from ID (ID >= 22)
      // but we store it for UI consistency.
      setIsReversed(reversed);
      setDrawState('revealed');
    }
  }, [deckData]);

  const handleReset = useCallback(() => {
    setDrawState('idle');
    setActiveCardData(null);
  }, []);

  const handleAcceptCard = useCallback(() => {
    if (activeCardData) {
       setHistory(prev => [...prev, {
         card: activeCardData,
         isReversed: isReversed,
         timestamp: Date.now()
       }]);
       handleReset();
    }
  }, [activeCardData, isReversed, handleReset]);

  // Deck Customization Handlers
  const handleUpdateCard = (id: number, newImage: string) => {
    setDeckData(prev => prev.map(card => 
      card.id === id ? { ...card, image: newImage } : card
    ));
  };

  // Loading Screen
  if (loading) {
    return (
      <div className="h-screen w-screen bg-black flex items-center justify-center text-cyber-gold font-cinzel animate-pulse">
        INITIALIZING ORACLE SYSTEMS...
      </div>
    );
  }

  // Start Screen (Will be skipped initially, but kept for logic safety)
  if (!started) {
    return (
      <div className="h-screen w-screen bg-black flex flex-col items-center justify-center text-cyber-gold relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/black-scales.png')] opacity-30"></div>
        <div className="z-10 text-center space-y-8">
           <h1 className="text-6xl font-cinzel tracking-[0.2em] text-transparent bg-clip-text bg-gradient-to-b from-cyber-gold to-cyber-dim drop-shadow-[0_0_15px_rgba(212,175,55,0.5)]">
             CYBER ARCANA
           </h1>
           <p className="font-serif text-cyber-neon/80 tracking-widest text-sm">
             GESTURAL DIVINATION INTERFACE
           </p>
           <button 
             onClick={handleStart}
             className="px-12 py-4 border border-cyber-gold text-cyber-gold font-cinzel text-xl hover:bg-cyber-gold hover:text-black transition-all duration-500 shadow-[0_0_20px_rgba(212,175,55,0.2)] hover:shadow-[0_0_40px_rgba(212,175,55,0.6)]"
           >
             ENTER THE VOID
           </button>
           <p className="text-xs text-gray-500 font-mono mt-8">
             *CAMERA PERMISSION REQUIRED FOR HAND TRACKING
           </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black text-cyber-gold font-serif">
      
      {/* Hidden Source Video for MediaPipe */}
      <video 
        ref={videoRef} 
        className="fixed top-0 left-0 opacity-0 pointer-events-none w-1 h-1" 
        playsInline 
        muted 
        autoPlay
      />

      {/* 3D Scene */}
      <TarotScene 
        deckData={deckData}
        handStatus={handStatus}
        inputMode={inputMode}
        onCardRevealed={handleCardRevealed}
        onReset={handleReset}
      />

      {/* UI Overlay */}
      {!showCustomizer && (
        <HUD 
            handStatus={handStatus}
            inputMode={inputMode}
            setInputMode={setInputMode}
            history={history}
            drawState={drawState}
            currentCardName={activeCardData?.name}
            // If isReversed (ID >= 22), the 'meaningReversed' property is used. 
            // Note: Since we expanded the deck, card.meaningReversed is populated correctly in data generation.
            currentCardMeaning={isReversed ? activeCardData?.meaningReversed : activeCardData?.meaningUpright}
            isReversed={isReversed}
            onAccept={handleAcceptCard}
            onOpenCustomizer={() => setShowCustomizer(true)}
        />
      )}

      {/* Deck Customizer Module */}
      {showCustomizer && (
          <DeckCustomizer 
            deckData={deckData}
            onUpdateCard={handleUpdateCard}
            onClose={() => setShowCustomizer(false)}
          />
      )}

      {/* Camera Feed & Skeleton Visualization (Top Right) - Hide when customizing */}
      <div className="absolute top-4 right-4 z-50 pointer-events-none transition-opacity duration-500" style={{opacity: (inputMode === 'hand' && !showCustomizer) ? 1 : 0}}>
         <div className="relative border border-cyber-gold/50 bg-black/80 shadow-[0_0_20px_rgba(212,175,55,0.2)] w-[320px] h-[240px]">
             <canvas 
               ref={canvasRef} 
               width={320} 
               height={240}
               className="w-full h-full object-cover opacity-80 scale-x-[-1]"
             />
             <div className="absolute bottom-1 right-2 text-[10px] text-cyber-neon font-mono">
               LIVE SENSOR FEED // {handStatus?.gesture || "SEARCHING"}
             </div>
             {/* Decorative UI elements */}
             <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-cyber-gold"></div>
             <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-cyber-gold"></div>
             <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-cyber-gold"></div>
             <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-cyber-gold"></div>
             
             {/* Crosshair */}
             <div className="absolute top-1/2 left-1/2 w-4 h-4 border border-cyber-gold/30 -translate-x-1/2 -translate-y-1/2 rounded-full"></div>
         </div>
      </div>

      {/* Global Vignette */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,transparent_0%,black_100%)] opacity-70"></div>
    </div>
  );
};

export default App;