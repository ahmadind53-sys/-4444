export interface TarotCardData {
  id: number;
  name: string;
  nameCN: string;
  image: string;
  meaningUpright: string;
  meaningReversed: string;
}

export interface DrawResult {
  card: TarotCardData;
  isReversed: boolean;
  timestamp: number;
}

export type AppMode = 'intro' | 'reading' | 'result' | 'summary';
export type InputMode = 'mouse' | 'hand';

export interface HandLandmark {
  x: number;
  y: number;
  z: number;
}

// Augment window for MediaPipe globals
declare global {
  interface Window {
    Hands: any;
    Camera: any;
    drawConnectors: any;
    drawLandmarks: any;
    HAND_CONNECTIONS: any;
  }
}
