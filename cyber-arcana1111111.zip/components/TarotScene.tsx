import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { TAROT_BACK_TEXTURE } from '../services/tarotData';
import { HandStatus } from '../services/handDetection';
import { InputMode, TarotCardData } from '../types';

interface TarotSceneProps {
  deckData: TarotCardData[];
  handStatus: HandStatus | null;
  inputMode: InputMode;
  onCardRevealed: (cardId: number, isReversed: boolean) => void;
  onReset: () => void;
}

// Shader for Card Back - "Flowing liquid gold/dark matter"
const cardBackVertexShader = `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const cardBackFragmentShader = `
  uniform float uTime;
  uniform sampler2D uTexture;
  varying vec2 vUv;

  // Simplex Noise (simplified)
  vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
  vec2 mod289(vec2 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
  vec3 permute(vec3 x) { return mod289(((x*34.0)+1.0)*x); }
  float snoise(vec2 v) {
    const vec4 C = vec4(0.211324865405187, 0.366025403784439, -0.577350269189626, 0.024390243902439);
    vec2 i  = floor(v + dot(v, C.yy) );
    vec2 x0 = v - i + dot(i, C.xx);
    vec2 i1;
    i1 = (x0.x > x0.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
    vec4 x12 = x0.xyxy + C.xxzz;
    x12.xy -= i1;
    i = mod289(i);
    vec3 p = permute( permute( i.y + vec3(0.0, i1.y, 1.0 )) + i.x + vec3(0.0, i1.x, 1.0 ));
    vec3 m = max(0.5 - vec3(dot(x0,x0), dot(x12.xy,x12.xy), dot(x12.zw,x12.zw)), 0.0);
    m = m*m ;
    m = m*m ;
    vec3 x = 2.0 * fract(p * C.www) - 1.0;
    vec3 h = abs(x) - 0.5;
    vec3 ox = floor(x + 0.5);
    vec3 a0 = x - ox;
    m *= 1.79284291400159 - 0.85373472095314 * ( a0*a0 + h*h );
    vec3 g;
    g.x  = a0.x  * x0.x  + h.x  * x0.y;
    g.yz = a0.yz * x12.xz + h.yz * x12.yw;
    return 130.0 * dot(m, g);
  }

  void main() {
    float n = snoise(vUv * 3.0 + uTime * 0.2);
    vec2 distortedUv = vUv + vec2(n * 0.02, n * 0.02);
    vec4 texColor = texture2D(uTexture, distortedUv);
    float sheen = smoothstep(0.3, 0.6, snoise(vUv * 5.0 - uTime * 0.5));
    vec3 gold = vec3(0.83, 0.68, 0.21);
    vec3 finalColor = mix(texColor.rgb * 0.5, gold, sheen * 0.5);
    gl_FragColor = vec4(finalColor, 1.0);
  }
`;

// Particle System
const particleVertexShader = `
  uniform float uTime;
  attribute float size;
  attribute float speed;
  varying float vOpacity;
  void main() {
    vec3 pos = position;
    pos.y = mod(pos.y + uTime * speed + 10.0, 20.0) - 10.0;
    pos.x += sin(uTime * speed + position.y) * 0.5;
    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_PointSize = size * (20.0 / -mvPosition.z);
    gl_Position = projectionMatrix * mvPosition;
    vOpacity = 1.0; 
  }
`;

const particleFragmentShader = `
  varying float vOpacity;
  void main() {
    float r = distance(gl_PointCoord, vec2(0.5));
    if (r > 0.5) discard;
    float glow = 1.0 - (r * 2.0);
    gl_FragColor = vec4(0.0, 0.95, 1.0, glow * 0.5);
  }
`;

export const TarotScene: React.FC<TarotSceneProps> = ({
  deckData,
  handStatus,
  inputMode,
  onCardRevealed,
  onReset
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  
  // Logic State
  const cardsRef = useRef<THREE.Group[]>([]);
  const selectedCardIdRef = useRef<number | null>(null);
  const appState = useRef<'STACKED' | 'SHUFFLING' | 'SELECTED' | 'REVEALED'>('STACKED');
  const wiggleCounter = useRef(0);
  const lastEmittedState = useRef<string>('STACKED');
  
  // Physics data
  const cardsData = useRef(deckData.map((card, i) => ({
    id: card.id,
    velocity: new THREE.Vector3(),
    position: new THREE.Vector3(0, 0, 0),
    rotation: new THREE.Euler(0, 0, 0),
    targetPosition: new THREE.Vector3(),
    targetRotation: new THREE.Euler(0, Math.PI, 0),
    noiseOffset: Math.random() * 100
  })));

  // Sync props to Ref
  const propsRef = useRef({ onCardRevealed, onReset });
  useEffect(() => {
    propsRef.current = { onCardRevealed, onReset };
  }, [onCardRevealed, onReset]);

  // Update textures when deckData changes
  useEffect(() => {
     // Re-init texture loader if needed, but primarily we check existing meshes
     const loader = new THREE.TextureLoader();
     loader.setCrossOrigin('anonymous');
     
     deckData.forEach((card, index) => {
         // Because deck size might change (initially) or update, ensure safe access
         if (cardsRef.current[index]) {
             const group = cardsRef.current[index];
             const frontMesh = group.children[0] as THREE.Mesh;
             const mat = frontMesh.material as THREE.MeshBasicMaterial;
             if (mat.userData.imageUrl !== card.image) {
                loader.load(card.image, (tex) => {
                    mat.map = tex;
                    mat.userData.imageUrl = card.image;
                    mat.needsUpdate = true;
                });
             }
         }
     });
  }, [deckData]);

  useEffect(() => {
    if (!containerRef.current) return;

    // Setup Three.js
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x050505, 0.04);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.1, 100);
    camera.position.z = 10;
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lights
    const ambientLight = new THREE.AmbientLight(0x404040, 2);
    scene.add(ambientLight);
    const pointLight = new THREE.PointLight(0x00f3ff, 2, 20);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);
    const goldLight = new THREE.PointLight(0xd4af37, 2, 20);
    goldLight.position.set(-5, -5, 5);
    scene.add(goldLight);

    // Background Particles
    const pGeo = new THREE.BufferGeometry();
    const pCount = 200;
    const pPos = new Float32Array(pCount * 3);
    const pSize = new Float32Array(pCount);
    const pSpeed = new Float32Array(pCount);
    for(let i=0; i<pCount; i++) {
        pPos[i*3] = (Math.random() - 0.5) * 30;
        pPos[i*3+1] = (Math.random() - 0.5) * 30;
        pPos[i*3+2] = (Math.random() - 0.5) * 20;
        pSize[i] = Math.random() * 0.5 + 0.1;
        pSpeed[i] = Math.random() * 0.5 + 0.1;
    }
    pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
    pGeo.setAttribute('size', new THREE.BufferAttribute(pSize, 1));
    pGeo.setAttribute('speed', new THREE.BufferAttribute(pSpeed, 1));
    const pMat = new THREE.ShaderMaterial({
        vertexShader: particleVertexShader,
        fragmentShader: particleFragmentShader,
        uniforms: { uTime: { value: 0 } },
        transparent: true,
        depthWrite: false,
        blending: THREE.AdditiveBlending
    });
    const particles = new THREE.Points(pGeo, pMat);
    scene.add(particles);

    // Cards
    const textureLoader = new THREE.TextureLoader();
    textureLoader.setCrossOrigin('anonymous');
    const backTex = textureLoader.load(TAROT_BACK_TEXTURE);
    const cardGeo = new THREE.PlaneGeometry(1.4, 2.2, 20, 20);
    
    // Initial Load using passed deckData
    deckData.forEach((data, i) => {
        const group = new THREE.Group();
        const frontTex = textureLoader.load(data.image);
        const frontMat = new THREE.MeshBasicMaterial({ map: frontTex });
        // Store image url to check for updates later
        frontMat.userData = { imageUrl: data.image, id: data.id };
        
        const frontMesh = new THREE.Mesh(cardGeo, frontMat);
        frontMesh.rotation.y = Math.PI; 
        frontMesh.position.z = -0.01;

        const backMat = new THREE.ShaderMaterial({
            vertexShader: cardBackVertexShader,
            fragmentShader: cardBackFragmentShader,
            uniforms: { uTime: { value: 0 }, uTexture: { value: backTex } }
        });
        const backMesh = new THREE.Mesh(cardGeo, backMat);
        group.add(frontMesh);
        group.add(backMesh);
        scene.add(group);
        cardsRef.current.push(group);
    });

    const clock = new THREE.Clock();
    
    const animate = () => {
      const time = clock.getElapsedTime();
      
      cardsRef.current.forEach(g => {
          const back = g.children[1] as THREE.Mesh;
          (back.material as THREE.ShaderMaterial).uniforms.uTime.value = time;
      });
      pMat.uniforms.uTime.value = time;

      updateCardPhysics(time);

      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    };
    
    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
        window.removeEventListener('resize', handleResize);
        containerRef.current?.removeChild(renderer.domElement);
    };
  }, []); // Re-run if mount logic needs to change, but mostly we handle updates via refs

  const statusRef = useRef(handStatus);
  statusRef.current = handStatus;

  const updateCardPhysics = (time: number) => {
      const status = statusRef.current;
      const cards = cardsRef.current;
      const data = cardsData.current;
      
      let targetState = appState.current;
      let handPos = new THREE.Vector3(0, 0, 0);

      if (status) {
          handPos.set((status.wristX - 0.5) * -20, (status.wristY - 0.5) * -14, 0);

          if (status.gesture === 'FIST') {
              targetState = 'STACKED';
              selectedCardIdRef.current = null;
          } else if (status.gesture === 'OPEN') {
              if (appState.current === 'SELECTED' || appState.current === 'REVEALED') {
                  selectedCardIdRef.current = null;
              }
              targetState = 'SHUFFLING';
          } else if (status.gesture === 'ONE_FINGER') {
              if (appState.current === 'SHUFFLING') {
                   if (selectedCardIdRef.current === null) {
                       const randomIdx = Math.floor(Math.random() * cards.length);
                       // Safely get ID from userData or index
                       const mesh = cards[randomIdx].children[0] as THREE.Mesh;
                       selectedCardIdRef.current = mesh.userData.id ?? randomIdx;
                   }
                   targetState = 'SELECTED';
              }
          }
      } else {
         // Optionally default to something if no hand, but keeping last state is often better for stability
      }

      // Gesture Trigger Logic: "Flip Backwards"
      // Positive Z velocity means moving away from camera.
      if ((targetState === 'SELECTED' || targetState === 'REVEALED') && status?.gesture === 'ONE_FINGER') {
          if (status.indexTipVelocityZ > 0.4) { 
             targetState = 'REVEALED';
          }
      }

      // State Transitions & Callbacks
      if (targetState !== lastEmittedState.current) {
          if (targetState === 'REVEALED' && lastEmittedState.current !== 'REVEALED') {
             if (selectedCardIdRef.current !== null) {
                // Determine reversal based on ID (0-21 Upright, 22-43 Reversed)
                const isReversed = selectedCardIdRef.current >= 22;
                propsRef.current.onCardRevealed(selectedCardIdRef.current, isReversed);
             }
          } else if (targetState === 'SHUFFLING' || targetState === 'STACKED') {
             if (lastEmittedState.current === 'REVEALED') {
                propsRef.current.onReset();
             }
          }
          lastEmittedState.current = targetState;
      }
      appState.current = targetState;

      // Physics Application
      data.forEach((d, i) => {
          const cardGroup = cards[i];
          const isSelected = (selectedCardIdRef.current === d.id);

          if (targetState === 'STACKED') {
              d.targetPosition.set(0, 0, -i * 0.01); 
              d.targetRotation.set(0, 0, 0); 
          } 
          else if (targetState === 'SHUFFLING') {
              const noiseX = Math.sin(time + d.noiseOffset) * 8;
              const noiseY = Math.cos(time * 0.8 + d.noiseOffset) * 5;
              const noiseZ = Math.sin(time * 1.2 + d.noiseOffset) * 2;
              d.targetPosition.set(handPos.x + noiseX, handPos.y + noiseY, handPos.z + noiseZ - 5);
              d.targetRotation.set(Math.sin(time + d.noiseOffset)*0.5, Math.sin(time*0.5+i)*0.5, Math.sin(time*0.3+i)*0.5);
          }
          else if (targetState === 'SELECTED' || targetState === 'REVEALED') {
              if (isSelected) {
                  d.targetPosition.set(0, 0, 6); 
                  if (targetState === 'REVEALED') {
                      const tiltX = (status?.wristY ?? 0.5) - 0.5;
                      const tiltY = (status?.wristX ?? 0.5) - 0.5;
                      d.targetRotation.set(tiltX, Math.PI + tiltY, 0);
                  } else {
                      d.targetRotation.set(0, 0, 0);
                  }
              } else {
                  const angle = (i / cards.length) * Math.PI * 2 + time * 0.1;
                  d.targetPosition.set(Math.cos(angle) * 15, Math.sin(angle) * 15, -10);
                  d.targetRotation.set(0, 0, time + i);
              }
          }

          d.position.lerp(d.targetPosition, 0.08); 
          cardGroup.position.copy(d.position);

          cardGroup.rotation.x += (d.targetRotation.x - cardGroup.rotation.x) * 0.08;
          cardGroup.rotation.y += (d.targetRotation.y - cardGroup.rotation.y) * 0.08;
          cardGroup.rotation.z += (d.targetRotation.z - cardGroup.rotation.z) * 0.08;
          
          if ((targetState === 'SELECTED' || targetState === 'REVEALED') && !isSelected) {
             cardGroup.scale.lerp(new THREE.Vector3(0.5,0.5,0.5), 0.1);
          } else {
             cardGroup.scale.lerp(new THREE.Vector3(1,1,1), 0.1);
          }
      });
  };

  return <div ref={containerRef} className="absolute inset-0 z-0 bg-cyber-black" />;
};