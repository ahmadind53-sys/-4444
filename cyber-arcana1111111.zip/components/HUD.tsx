import React from 'react';
import { HandStatus } from '../services/handDetection';
import { DrawResult, InputMode } from '../types';
import clsx from 'clsx'; // Assuming standard class manipulation

interface HUDProps {
  handStatus: HandStatus | null;
  inputMode: InputMode;
  setInputMode: (m: InputMode) => void;
  history: DrawResult[];
  drawState: string;
  currentCardName: string | null;
  currentCardMeaning: string | null;
  isReversed: boolean;
  onAccept: () => void;
  onOpenCustomizer: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  handStatus,
  inputMode,
  setInputMode,
  history,
  drawState,
  currentCardName,
  currentCardMeaning,
  isReversed,
  onAccept,
  onOpenCustomizer
}) => {
  return (
    <div className="absolute inset-0 pointer-events-none z-10 flex flex-col justify-between p-6">
      
      {/* Top Bar */}
      <div className="flex justify-between items-start">
        <div className="border-l-2 border-cyber-gold pl-3">
          <h1 className="font-cinzel text-3xl text-cyber-gold hud-text tracking-widest">CYBER ARCANA</h1>
          <div className="text-xs text-cyber-neon font-mono animate-pulse">SYSTEM ONLINE // AWAITING FATE</div>
        </div>
        
        <div className="flex flex-col items-end gap-2">
          <div className={clsx(
            "px-4 py-1 border border-cyber-gold/50 bg-black/50 text-xs font-mono",
            inputMode === 'hand' ? "text-cyber-neon" : "text-gray-500"
          )}>
            SENSOR STATUS: {handStatus ? "TRACKING" : "SEARCHING..."}
          </div>
          {inputMode === 'hand' && handStatus && (
            <div className="text-right text-xs text-white/50 font-mono">
              GESTURE: <span className="text-cyber-gold font-bold">{handStatus.gesture}</span>
              <br/>
              X: {handStatus.wristX.toFixed(2)}
            </div>
          )}
        </div>
      </div>

      {/* Center Action / Info Area */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        
        {/* Intro Text */}
        {drawState === 'idle' && history.length === 0 && (
           <div className="text-center bg-black/60 p-6 backdrop-blur-sm border-t border-b border-cyber-gold/20">
              <p className="font-serif text-white/80 mb-2">Initialize Sequence</p>
              <p className="text-cyber-gold font-cinzel text-xl animate-pulse-fast">
                {inputMode === 'hand' ? "RAISE HAND TO BEGIN" : "CLICK DECK TO DRAW"}
              </p>
              {inputMode === 'hand' && <div className="mt-4 text-xs font-mono text-cyber-neon">
                PAN: Wave Left/Right <br/> SELECT: Fist <br/> CONFIRM: Hold Fist (10s)
              </div>}
           </div>
        )}

        {/* Card Reveal Panel */}
        {drawState === 'revealed' && (
          <div className="mt-64 text-center pointer-events-auto animate-in fade-in zoom-in duration-500">
             <h2 className="text-4xl text-cyber-gold font-cinzel mb-2 hud-text">{currentCardName}</h2>
             <div className="text-xl text-cyber-neon font-serif mb-4 tracking-widest uppercase">
               {isReversed ? "[ REVERSED ]" : "[ UPRIGHT ]"}
             </div>
             <p className="max-w-md text-white/90 font-serif leading-relaxed bg-black/80 p-4 border border-cyber-gold/30">
               {currentCardMeaning}
             </p>
             
             <button 
               onClick={onAccept}
               className="mt-6 px-8 py-2 border border-cyber-gold text-cyber-gold hover:bg-cyber-gold hover:text-black transition-colors font-cinzel tracking-widest text-lg"
             >
               ACCEPT FATE
             </button>
             
             {inputMode === 'hand' && (
               <div className="mt-2 text-xs text-gray-400 font-mono">or make FIST to accept</div>
             )}
          </div>
        )}
      </div>

      {/* Bottom Controls */}
      <div className="flex justify-center items-end gap-4 pointer-events-auto pb-4">
         <div className="bg-black/80 border border-cyber-dim p-1 flex rounded items-center gap-4">
            <button 
              onClick={() => setInputMode('hand')}
              className={clsx("px-4 py-2 text-sm font-mono transition-colors", inputMode === 'hand' ? "bg-cyber-dim text-cyber-gold" : "text-gray-500 hover:text-white")}
            >
              HAND SYS
            </button>
            <button 
              onClick={() => setInputMode('mouse')}
              className={clsx("px-4 py-2 text-sm font-mono transition-colors", inputMode === 'mouse' ? "bg-cyber-dim text-cyber-gold" : "text-gray-500 hover:text-white")}
            >
              MOUSE SYS
            </button>
            
            <div className="w-px h-6 bg-cyber-gold/30 mx-1"></div>
            
            <button
                onClick={onOpenCustomizer}
                className="px-4 py-2 text-sm font-mono text-cyber-neon hover:text-white transition-colors"
            >
                CUSTOMIZE
            </button>
         </div>
      </div>

      {/* Bottom Left: History Log */}
      <div className="absolute left-6 bottom-6 pointer-events-auto">
        <div className="text-[10px] text-cyber-gold font-mono mb-1 border-b border-cyber-gold/20 inline-block">READING LOG</div>
        <div className="flex gap-4 items-end max-w-[50vw] overflow-x-auto no-scrollbar pb-2">
            {history.map((item, idx) => (
            <div key={idx} className="relative group shrink-0">
                <div className="w-16 h-24 border border-cyber-gold/30 bg-black/80 transition-all group-hover:scale-110 group-hover:-translate-y-4 group-hover:border-cyber-neon group-hover:shadow-[0_0_10px_rgba(0,243,255,0.3)] cursor-help z-0 group-hover:z-50">
                    <img 
                        src={item.card.image} 
                        className={clsx(
                            "w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-all",
                        )} 
                        alt={item.card.name}
                    />
                    
                    {/* Reversal Indicator */}
                    {item.isReversed && (
                        <div className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border border-black shadow-[0_0_5px_red]" title="Reversed"></div>
                    )}
                </div>
                
                {/* Tooltip */}
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-32 bg-black/95 border border-cyber-gold p-2 text-center pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-50 shadow-xl">
                    <div className="text-cyber-gold font-cinzel text-xs font-bold leading-tight">{item.card.name}</div>
                    <div className="text-cyber-neon text-[10px] font-mono mt-1">{item.isReversed ? "[ REV ]" : "[ UPR ]"}</div>
                </div>
            </div>
            ))}
            {history.length === 0 && (
                <div className="text-xs text-gray-700 font-mono italic p-2 border border-dashed border-gray-800">
                    [ NO CARDS DRAWN ]
                </div>
            )}
        </div>
      </div>
      
    </div>
  );
};