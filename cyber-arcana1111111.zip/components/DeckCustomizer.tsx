import React, { useRef, useState } from 'react';
import { TarotCardData } from '../types';
import clsx from 'clsx';

interface DeckCustomizerProps {
  deckData: TarotCardData[];
  onUpdateCard: (id: number, newImage: string) => void;
  onClose: () => void;
}

export const DeckCustomizer: React.FC<DeckCustomizerProps> = ({ deckData, onUpdateCard, onClose }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const selectedIdRef = useRef<number | null>(null);
  const [activeTab, setActiveTab] = useState<'upright' | 'reversed'>('upright');

  const handleCardClick = (id: number) => {
    selectedIdRef.current = id;
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && selectedIdRef.current !== null) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        if (ev.target?.result) {
          onUpdateCard(selectedIdRef.current!, ev.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Filter cards based on tab
  const displayCards = deckData.filter(c => 
    activeTab === 'upright' ? c.id < 22 : c.id >= 22
  );

  return (
    <div className="absolute inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col p-8 overflow-hidden animate-in fade-in duration-300">
      <div className="flex justify-between items-center mb-6 border-b border-cyber-gold/30 pb-4">
        <div className="flex flex-col">
            <h2 className="text-3xl font-cinzel text-cyber-gold tracking-widest">DECK MODIFICATION</h2>
            <span className="text-xs font-mono text-cyber-neon">OVERRIDE VISUAL MATRIX</span>
        </div>
        <button onClick={onClose} className="border border-cyber-neon text-cyber-neon px-4 py-2 font-mono hover:bg-cyber-neon hover:text-black transition-colors text-sm">
          [ CLOSE_MODULE ]
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 mb-4 font-mono text-sm">
        <button 
            onClick={() => setActiveTab('upright')}
            className={clsx(
                "px-4 py-2 border transition-all",
                activeTab === 'upright' ? "border-cyber-gold bg-cyber-gold/20 text-cyber-gold" : "border-gray-800 text-gray-500 hover:text-white"
            )}
        >
            UPRIGHT (0-21)
        </button>
        <button 
            onClick={() => setActiveTab('reversed')}
            className={clsx(
                "px-4 py-2 border transition-all",
                activeTab === 'reversed' ? "border-cyber-gold bg-cyber-gold/20 text-cyber-gold" : "border-gray-800 text-gray-500 hover:text-white"
            )}
        >
            REVERSED (22-43)
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto pr-2">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6 pb-20">
            {displayCards.map((card) => (
            <div 
                key={card.id} 
                onClick={() => handleCardClick(card.id)}
                className="relative aspect-[2/3] group cursor-pointer border border-cyber-gold/20 hover:border-cyber-gold hover:shadow-[0_0_15px_rgba(212,175,55,0.3)] transition-all bg-black"
            >
                <img src={card.image} alt={card.name} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                
                {/* Overlay Info */}
                <div className="absolute bottom-0 inset-x-0 bg-black/80 p-2 text-center border-t border-cyber-gold/10">
                <span className="text-[10px] text-cyber-gold font-mono uppercase truncate block">{card.id}. {card.name}</span>
                </div>
                
                {/* Hover Action */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 bg-black/60 transition-opacity backdrop-blur-[2px]">
                <div className="text-cyber-neon text-xs font-mono border border-cyber-neon px-3 py-1 bg-black">
                    UPLOAD {activeTab === 'reversed' ? 'REV' : ''} IMG
                </div>
                </div>
            </div>
            ))}
        </div>
      </div>

      <input 
        type="file" 
        ref={fileInputRef} 
        className="hidden" 
        accept="image/*" 
        onChange={handleFileChange}
      />
      
      <div className="absolute bottom-0 left-0 right-0 bg-black/90 border-t border-cyber-gold/20 p-2 text-center">
        <p className="text-[10px] text-gray-500 font-mono">
            System Warning: Custom reversed cards will be displayed exactly as uploaded (no auto-rotation).
        </p>
      </div>
    </div>
  );
};